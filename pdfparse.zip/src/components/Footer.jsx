import React from 'react'

const Footer = () => {

    


    return (
        <div className='footer z-3  bg-white   ' style={{backgroundColor: "#F7FFDD", color: "#815F0B",direction: "ltr"}} >
            {/* <hr className='p-0 m-0  ' /> */}
            <div className='font-6 d-flex justify-content-between px-3  px-lg-2   '>
                <div className='' > &copy; Copyright MyST, 2023</div>
                <div>Powered by MyST</div>
            </div>
        </div>
    )
}

export default Footer