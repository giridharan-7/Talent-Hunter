import './App.css';
import JdBasedSearch from './pages/JdBasedSearch';

function App() {
  return (
    <JdBasedSearch />
  );
}

export default App;
